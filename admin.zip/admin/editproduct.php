<?php
session_start();
include_once('connection.php');

$id2=$_GET['id1'];

$sql="select * from product where ProductId=$id2";
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_assoc($result);
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Index</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href="style.css" rel="stylesheet" type="text/css" />
<!-- CuFon: Enables smooth pretty custom font rendering. 100% SEO friendly. To disable, remove this section 
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/arial.js"></script>
<script type="text/javascript" src="js/cuf_run.js"></script>
 CuFon ends -->
</head>
<body>
<div class="main">

  <div class="header">
    <div class="header_resize">
      <div class="logo"><h1><a href="index.php" class="nobg">
	  <i>ADMIN</i></a></h1></div>
      <div class="menu_nav">
        <ul>
          <li><a href="index.php">Home</a></li>
          <li ><a href='viewcustomer.php'>View Customers</a></li>
          <li><a href='viewproduct.php'>View Product</a></li>
          
        </ul>
      </div>
	  <br><br><br><br><br>
	  <div class="menu_login" >
        <ul>
          <li><a href="logout.php" ><?php
          if(!isset($_SESSION['username']))
          {
            echo "Login";
          }
          else
          {
            echo "Logout";  
          }
          ?></a>
		  <?php
		  /*if(!empty($_REQUEST['logout']))
		  {
			 echo "session destroyed";
		  session_destroy();
		  }
		  
		  //session_destroy();   */
		  ?>
          </li>
          <li class="active"><a>
		  <?php
          if(empty($_SESSION['username']))
          {
            echo "Guest";
          }
          else
          {
            echo "Admin";  
          }
          
          ?>
		  </a></li>
        </ul>
      </div>
      <div class="clr"></div>
    </div>
  </div>
   <div class="content">
    <div class="content_resize">
      <div class="mainbar">



      <form method='post'>
<table align='center' border=1>
    <tr><td>Product ID</td><td>:</td><td>
	<input type="text" value="<?php echo $row['ProductId'];?>" readonly /></td></tr>
	<tr><td>Product name</td><td>:</td><td><input type="text" name="t1" value="<?php echo $row['ProductName'];?>" /></td></tr>
	<tr><td>Description</td><td>:</td><td><input type="text" name="t2" value="<?php echo $row['ProductDescription'];?>" /></td></tr>
	<tr><td>Photo</td><td>:</td><td><?php $target_path1="images/";
                $image=$target_path1.$row['ProductImage'];
                echo "<img src=".$image." width=70 height=100/> ";?></td></tr>
    
	<tr><td colspan=3><center><input type="submit" name="submit" value='update' /><center></td></tr>
        </table>

</form>

<?php 

if(isset($_POST['submit']))
{
	$name=$_POST['t1'];
	$des=$_POST['t2'];
    
	
	$sql="update product set ProductName='$name', ProductDescription='$des' where ProductId='$id2'";
	if(mysqli_query($conn,$sql))
	{
		header("location:viewproduct.php");
	}
}
	
?>





 


	 
	
		</div>
		<div class="clr"></div>
		<hr style="height:5px;border-width:0;color:gray;background-color:gray">
        
      </div>
      <div class="clr"></div>
    </div>
    

  </div>

  <div class="fbg">
    <div class="fbg_resize">
      
      <div class="col c2">
        <h2 style="color:#194e5c">About US</h2>
		<a href="images/gb.jpg"><img src="images/gb.jpg" style="float:left" title="Gaurav" width="170px" height="150px"></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<a href="images/ishika.jpg"><img src="images/ishika.jpg" style="float:center" title="Ishika" width="100px" height="150px"></a>
        <p>Enrollment Number:<li>19012011004 Bilandani Gauravkumar Jayeshkumar</li>
		<li>20012012012 Jain Ishika</li><br>
		Students of 6th Semester Computer Engineering in U. V. Patel College Of Engineering</p>
        <ul class="sb_menu">	
         
        </ul>
        <p>OH MY GAWD! Yeh toh Bohot Krazy Kar Diya Maine</p>
      </div>
      <div class="col c3">
        <h2 style="color:#194e5c">Contact</h2>
        <a href="images/photo.jpg"><img src="images/photo.jpg" width="100" height="150px" alt="photo" /></a>
        <p></p>	
        <p><strong>Phone:</strong><a style="color:#194e5c" href="callto:+919998819801">+91 9998819801</a><br>
          <strong>Address:</strong><br><a style="color:#194e5c" href="https://www.google.com/maps/dir//23.5285594,72.458591/@23.5275462,72.4571784,18.19z/data=!4m2!4m1!3e0">
		  6CEIT-C,&nbsp; B-Tech,<br>U. V. Patel College Of Engineering,<br> Ganpat University - 384012 .</a>
		  <br>
		  <br><br><br>
          <strong>E-mail:</strong>
		  <ul> 
		  <li><a style="color:#194e5c" href="mailto:gauravkumarbilandani19@gnu.ac.in">gauravkumarbilandani19@gnu.ac.in</a></li>
		  <li><a style="color:#194e5c" href="mailto:ishikajain20@gnu.ac.in">ishikajain20@gnu.ac.in</a></li>
		  </ul>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="footer">
    <div class="footer_resize">
      <p class="lf" style="color:#cff6f4">&copy; Gaurav Bilandani and Jain Ishika </a></p>
      
      <div class="clr"></div>
    </div>
  </div>
</div>
</div>
 </body>
</html>

