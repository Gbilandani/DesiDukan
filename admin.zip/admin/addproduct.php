<?php
session_start();
include_once('connection.php');


?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Index</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link href="style.css" rel="stylesheet" type="text/css" />
<!-- CuFon: Enables smooth pretty custom font rendering. 100% SEO friendly. To disable, remove this section 
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script type="text/javascript" src="js/arial.js"></script>
<script type="text/javascript" src="js/cuf_run.js"></script>
 CuFon ends -->
</head>





<body>
<div class="main">

  <div class="header">
    <div class="header_resize">
      <div class="logo"><h1><a href="index.php" class="nobg">
	  <i>ADMIN</i></a></h1></div>
      <div class="menu_nav">
        <ul>
          <li><a href="index.php">Home</a></li>
          <li ><a href='viewcustomer.php'>View Customers</a></li>
          <li><a href='viewproduct.php'>View Product</a></li>
          
        </ul>
      </div>
	  <br><br><br><br><br>
	  <div class="menu_login" >
        <ul>
          <li><a href="logout.php" ><?php
          if(!isset($_SESSION['username']))
          {
            echo "Login";
          }
          else
          {
            echo "Logout";  
          }
          ?></a>
		  <?php
		  /*if(!empty($_REQUEST['logout']))
		  {
			 echo "session destroyed";
		  session_destroy();
		  }
		  
		  //session_destroy();   */
		  ?>
          </li>
          <li class="active"><a>
		  <?php
          if(empty($_SESSION['username']))
          {
            echo "Guest";
          }
          else
          {
            echo "Admin";  
          }
          
          ?>
		  </a></li>
        </ul>
      </div>
      <div class="clr"></div>
    </div>
  </div>
   <div class="content">
    <div class="content_resize">
      <div class="mainbar">
          <center><h3>Add Product</h3></center>


<?php

if(isset($_POST['submit']))
{
$name=$_POST['ProductName'];
$desc=$_POST['Description'];
$catname=$_POST['category'];
$selectcat = mysqli_query($conn,"select * from category where name= '$catname'") ;
				   $rowcat = mysqli_fetch_assoc($selectcat);
				   	$catid = $rowcat['CatId'];
$subcat=$_POST['subcategory'];
$selectsubcat = mysqli_query($conn,"select * from subcategory where name= '$subcat'") ;
				   $rowscat = mysqli_fetch_assoc($selectsubcat);
				   	$subcatid = $rowscat['id'];
//$color=$_POST['Color'];
//$size=$_POST['Size'];
//$qty=$_POST['qty'];
$price=$_POST['Price'];

$frontimg=$_FILES['ProductImage']['name'];
$target_path="./images/";


$target_path1=$target_path.$frontimg;
$source_img = $_FILES['ProductImage']['tmp_name'];



move_uploaded_file($source_img,$target_path1);



$insert="insert into product(ProductName,ProductDescription,CatId,subcatId,Size,Qty,ProductPrice,ProductImage) values ('$name','$desc','$catid','$subcatid','$size','$qty','$price','$frontimg')";


if(mysqli_query($conn,$insert))
{
    //echo "<center>Inserted</center>";
    //header('location:addproduct.php?insert=success');
    header('location:viewproduct.php?insert=success');
    //header('Location:viewproduct.php?insert=success');
}
}
?>
<form name="ProductDetails" method="post" enctype="multipart/form-data">
    <center>
 
 <table align="center" border="0"> <center>
 <tr>
 <td colspan="3"> <center>
 Add Product </center></td>
 </tr>
  <tr>
   <td class="txt" align="center">Product Name &nbsp;</td>
    <td><input type="text" name="ProductName" id="productname" value="" /></td>
  </tr>
   <tr>
    <td class="txt" align="center">Description &nbsp;</td>
     <td><textarea name="Description" id="description" rows="3"  cols="20" value="" class="txtbox" ></textarea></td> <br><br>
    </tr>
        <tr>
               <td class="txt" align="center">Category &nbsp;</td>
               <td><?php
                    include_once('connection.php');
                    $query1 = "SELECT CatId, name FROM category";
                    $result1 = mysqli_query( $conn,$query1) or die(mysqli_error()); 
                     echo "<select name='category' class='dd' id='category' onChange='return getsubcategory(this.value);'>";
                    ?>
                   
                   <option value="select">---Select---</option>
                   
                   <?php
                    while ($row = mysqli_fetch_array( $result1 )) {
                         $name=$row['name'];
                    echo '<option value="'.$name.'">'.$name.'</option>';
                      }
               ?>
                 </select></td>
        </tr>
        <tr>
               <td class="txt" align="center">Sub Category &nbsp;</td>
               <td><?php
                    include_once('connection.php');
                    $query1 = "SELECT id, name FROM subcategory";
                    $result1 = mysqli_query( $conn,$query1) or die(mysqli_error()); 
                     echo "<select name='subcategory' class='dd' id='category' onChange='return getsubcategory(this.value);'>";
                    ?>
                   
                   <option value="select">---Select---</option>
                   
                   <?php
                    while ($row = mysqli_fetch_array( $result1 )) {
                         $name=$row['name'];
                    echo '<option value="'.$name.'">'.$name.'</option>';
                      }
               ?>
                 </select></td>
        </tr>
     <tr>
                   <?php /*?> <?php
                    include_once('connection.php');
                    $query1 = "SELECT SubCatId,SubCatName FROM subcategory";
                    $result1 = mysql_query( $query1) or die(mysql_error()); 
                     echo "<select name='subcatname'>";
                    ?>
                         <option>---select---</option>
                   <?php
                    while ($row = mysql_fetch_array( $result1 )) {
                    echo "<option value='" . $row['SubCatId'] ."'>" . $row['SubCatName'] ."</option>";
                      }
               ?><?php */?>
      </tr>
       <tr>
         <!---
        <td class="txt" align="center">Color &nbsp;</td>
         <td><?php /*
                    include_once('connection.php');
                    $query1 = "SELECT Color_Id,Color FROM color";
                    $result1 = mysqli_query( $conn,$query1) or die(mysqli_error()); 
                     echo "<select name='Color' class='dd' id='color'>";
                    ?>
                 <option value="select">---select---</option>
                 <?php
                    while ($row = mysqli_fetch_array( $result1 )) {
                         $color=$row['Color'];
                    echo '<option value="'.$color.'">'.$color.'</option>';
                      }
              */ ?></td>
             </tr>       
       <tr>
        <td class="txt" align="center">Size &nbsp;</td>
         <td><?php/*
                    include_once('connection.php');
                    $query1 = "SELECT Size_Id,Size FROM size";
                    $result1 = mysqli_query($conn, $query1) or die(mysqli_error()); 
                     echo "<select name='Size' class='dd' id='size'>";
                   */ ?>
                 <option value="select">---select---</option>
                 <?php/*
                    while ($row = mysqli_fetch_array( $result1 )) {
                        $size=$row['Size'];
                     echo '<option value="'.$size.'">'.$size.'</option>';
                      }
               */?></td>
       </tr>
       <tr>
       <td class="txt" align="center">Quantity &nbsp;</td>
         <td><?php/*
                    include_once('connection.php');
                    $query1 = "SELECT QtyId,Qty FROM quantity";
                    $result1 = mysqli_query($conn, $query1) or die(mysqli_error()); 
                     echo "<select name='qty' class='dd' id='qty'>";
                   */ ?>
                 <option value="select">---select---</option>
                 <?php/*
                    while ($row = mysqli_fetch_array( $result1 )) {
                        $qty=$row['Qty'];
                     echo '<option value="'.$qty.'">'.$qty.'</option>';
                      }
               */?></td>
             
       </tr>
       ------>
       <tr>
               <td class="txt" align="center">Price &nbsp;</td>
               <td><input type="text" name="Price" id="price" value=""  class="txtbox" /></td>
             </tr>
              <tr>
        <td class="txt" align="center">Image &nbsp;</td>
        <td><input type="file" id="productimg" name="ProductImage" value=""  class="txtbox"/></td>
 
       </tr>
       <tr></tr>
      <tr>
       <td align="center" colspan="2"><input type="submit" name="submit" value="Submit" />
    <input type="reset" name="reset" value="Cancel" /></td>
   
      </tr>
 
 
 
 </center>
 </table>  
 </center>
 </form>
 


	 
	
		</div>
		<div class="clr"></div>
		<hr style="height:5px;border-width:0;color:gray;background-color:gray">
        
      </div>
      <div class="clr"></div>
    </div>
    

  </div>

  <div class="fbg">
    <div class="fbg_resize">
      
      <div class="col c2">
        <h2 style="color:#194e5c">About US</h2>
		<a href="images/gb.jpg"><img src="images/gb.jpg" style="float:left" title="Gaurav" width="170px" height="150px"></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<a href="images/ishika.jpg"><img src="images/ishika.jpg" style="float:center" title="Ishika" width="100px" height="150px"></a>
        <p>Enrollment Number:<li>19012011004 Bilandani Gauravkumar Jayeshkumar</li>
		<li>20012012012 Jain Ishika</li><br>
		Students of 6th Semester Computer Engineering in U. V. Patel College Of Engineering</p>
        <ul class="sb_menu">	
         
        </ul>
        <p>OH MY GAWD! Yeh toh Bohot Krazy Kar Diya Maine</p>
      </div>
      <div class="col c3">
        <h2 style="color:#194e5c">Contact</h2>
        <a href="images/photo.jpg"><img src="images/photo.jpg" width="100" height="150px" alt="photo" /></a>
        <p></p>	
        <p><strong>Phone:</strong><a style="color:#194e5c" href="callto:+919998819801">+91 9998819801</a><br>
          <strong>Address:</strong><br><a style="color:#194e5c" href="https://www.google.com/maps/dir//23.5285594,72.458591/@23.5275462,72.4571784,18.19z/data=!4m2!4m1!3e0">
		  6CEIT-C,&nbsp; B-Tech,<br>U. V. Patel College Of Engineering,<br> Ganpat University - 384012 .</a>
		  <br>
		  <br><br><br>
          <strong>E-mail:</strong>
		  <ul> 
		  <li><a style="color:#194e5c" href="mailto:gauravkumarbilandani19@gnu.ac.in">gauravkumarbilandani19@gnu.ac.in</a></li>
		  <li><a style="color:#194e5c" href="mailto:ishikajain20@gnu.ac.in">ishikajain20@gnu.ac.in</a></li>
		  </ul>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <div class="footer">
    <div class="footer_resize">
      <p class="lf" style="color:#cff6f4">&copy; Gaurav Bilandani and Jain Ishika </a></p>
      
      <div class="clr"></div>
    </div>
  </div>
</div>
</div>
 </body>
</html>

