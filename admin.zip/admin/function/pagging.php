<?php



$servername = "localhost";
$username = "root";
$password = "";
$db = "dbos";
$conn = mysqli_connect($servername, $username, $password,$db);
if (!$conn)
    {
   echo "Connection failed";
}

function getPagingNav($sql, $pageNum, $rowsPerPage, $queryString = '')
{

	$result  = mysqli_query($sql) or die('Error, query failed. ' . mysqli_error());
	$row     = mysqli_fetch_array($result, MYSQL_ASSOC);
	$numrows = $row['numrows'];
	
	// how many pages we have when using paging?
	$maxPage = ceil($numrows/$rowsPerPage);
	
 		
	if ($_SERVER['SERVER_PORT']!=443)
	{
 		$self = 'http://' . $_SERVER['PHP_SELF'] ;
 	}
 	else
 	{
 		
 		$self = 'https://' . $_SERVER['PHP_SELF'] ;

 	}


	
	// creating 'previous' and 'next' link
	// plus 'first page' and 'last page' link
	
	// print 'previous' link only if we're not
	// on page one
	if ($pageNum > 1)
	{
		$page = $pageNum - 1;
		$prev = " <a href=\"$self?pagenum=$page{$queryString}\">[Prev]</a> ";
	
		$first = " <a href=\"$self?pagenum=1{$queryString}\">[First Page]</a> ";
	}
	else
	{
		$prev  = ' [Prev] ';       // we're on page one, don't enable 'previous' link
		$first = ' [First Page] '; // nor 'first page' link
	}
	
	// print 'next' link only if we're not
	// on the last page
	if ($pageNum < $maxPage)
	{
		$page = $pageNum + 1;
		$next = " <a href=\"$self?pagenum=$page{$queryString}\">[Next]</a> ";
	
		$last = " <a href=\"$self?pagenum=$maxPage{$queryString}{$queryString}\">[Last Page]</a> ";
	}
	else
	{
		$next = ' [Next] ';      // we're on the last page, don't enable 'next' link
		$last = ' [Last Page] '; // nor 'last page' link
	}
	
	// return the page navigation link
	return $first . $prev . " Showing page <strong>$pageNum</strong> of <strong>$maxPage</strong> pages " . $next . $last; 
}


function getPagingQuery($sql, $itemPerPage = 10)
{
	if (isset($_GET['pagenum']) && (int)$_GET['pagenum'] > 0) {
		$page = (int)$_GET['pagenum'];
	} else {
		$page = 1;
	}
	
	// start fetching from this row number
	$offset = ($page - 1) * $itemPerPage;
	
	return $sql . " LIMIT $offset, $itemPerPage";
}

/*
	Get the links to navigate between one result page to another.
	Supply a value for $strGet if the page url already contain some
	GET values for example if the original page url is like this :
	
	http://www.phpwebcommerce.com/plaincart/index.php?c=12
	
	use "c=12" as the value for $strGet. But if the url is like this :
	
	http://www.phpwebcommerce.com/plaincart/index.php
	
	then there's no need to set a value for $strGet
	
	
*/
function getPagingLink($sql, $itemPerPage = 10, $strGet = '')
{
	
	$servername = "localhost";
	$username = "root";
	$password = "";
	$db = "dbos";
	$conn = mysqli_connect($servername, $username, $password,$db);
	if (!$conn)
    {
	   echo "Connection failed";
	}
	$result        = mysqli_query($conn,$sql);
	$pagingLink    = '';
	$totalResults  = mysqli_num_rows($result);
	$totalPages    = ceil($totalResults / $itemPerPage);
	
	// how many link pages to show
	$numLinks      = 10;

		
	// create the paging links only if we have more than one page of results
	if ($totalPages > 1) {
	
	if ($_SERVER['SERVER_PORT']!=443)
	{
 		$self = 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'] ;
 	}
 	else
 	{

 		$self = 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'] ;

 	}
		

		if (isset($_GET['pagenum']) && (int)$_GET['pagenum'] > 0) {
			$pageNumber = (int)$_GET['pagenum'];
		} else {
			$pageNumber = 1;
		}
		
		// print 'previous' link only if we're not
		// on page one
		if ($pageNumber > 1) {
			$page = $pageNumber - 1;
			if ($page > 1) {
				$prev = " <a href=\"$self?pagenum=$page&$strGet/\">[Prev]</a> ";
			} else {
				$prev = " <a href=\"$self?$strGet\">[Prev]</a> ";
			}	
				
			$first = " <a href=\"$self?$strGet\">[First]</a> ";
		} else {
			$prev  = ''; // we're on page one, don't show 'previous' link
			$first = ''; // nor 'first page' link
		}
	
		// print 'next' link only if we're not
		// on the last page
		if ($pageNumber < $totalPages) {
			$page = $pageNumber + 1;
			$next = " <a href=\"$self?pagenum=$page&$strGet\">[Next]</a> ";
			$last = " <a href=\"$self?pagenum=$totalPages&$strGet\">[Last]</a> ";
		} else {
			$next = ''; // we're on the last page, don't show 'next' link
			$last = ''; // nor 'last page' link
		}

		$start = $pageNumber - ($pageNumber % $numLinks) + 1;
		$end   = $start + $numLinks - 1;		
		
		$end   = min($totalPages, $end);
		
		$pagingLink = array();
		for($page = $start; $page <= $end; $page++)	{
			if ($page == $pageNumber) {
				$pagingLink[] = " $page ";   // no need to create a link to current page
			} else {
				if ($page == 1) {
					$pagingLink[] = "  <a href=\"$self?$strGet\">$page</a> ";
				} else {	
					$pagingLink[] = "  <a href=\"$self?pagenum=$page&$strGet\">$page</a> ";
				}	
			}
	
		}
		
		$pagingLink = implode(' | ', $pagingLink);
		
		// return the page navigation link
		$pagingLink = $first . $prev . $pagingLink . $next . $last;
	}
	
	return $pagingLink;
}

?>