-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 02, 2022 at 01:34 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbos`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminlogin`
--

CREATE TABLE `adminlogin` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `adminlogin`
--

INSERT INTO `adminlogin` (`username`, `password`) VALUES
('gb@gmail.com', '987456321');

-- --------------------------------------------------------

--
-- Table structure for table `bill`
--

CREATE TABLE `bill` (
  `email` varchar(255) NOT NULL,
  `productid` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `productname` varchar(20) NOT NULL,
  `size` int(11) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `email` varchar(255) NOT NULL,
  `productid` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `productname` varchar(20) NOT NULL,
  `size` int(11) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `CatId` int(11) NOT NULL,
  `name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`CatId`, `name`) VALUES
(1, 'Man'),
(2, 'Women'),
(3, 'Children');

-- --------------------------------------------------------

--
-- Table structure for table `color`
--

CREATE TABLE `color` (
  `Color_Id` int(7) NOT NULL,
  `Color` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `color`
--

INSERT INTO `color` (`Color_Id`, `Color`) VALUES
(2, 'Black'),
(3, 'White'),
(4, 'Blue');

-- --------------------------------------------------------

--
-- Table structure for table `databaselos`
--

CREATE TABLE `databaselos` (
  `id` int(11) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `mobilenumber` bigint(10) NOT NULL,
  `society` varchar(50) NOT NULL,
  `street` varchar(50) NOT NULL,
  `area` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `databaselos`
--

INSERT INTO `databaselos` (`id`, `firstname`, `lastname`, `email`, `password`, `mobilenumber`, `society`, `street`, `area`) VALUES
(18, 'helloaxad', 'ascr', 'ase@gma.cm', '98745632', 9874564785, '', '', ''),
(22, 'hduf', 'sg', 'dff@dg.com', '74185214', 7896541235, '', '', ''),
(20, 'jkasaf', 'fhf', 'dhd@ma.com', '74185236', 9874563214, '', '', ''),
(23, 'asas', 'asas', 'gb1@gmail.com', '12345r123', 2323232323, '', '', ''),
(26, 'helloworld', 'xyz', 'gb3@gmail.com', '987456321', 3698521478, '', '', ''),
(12, 'Mohit', 'Kumar', 'gb@gmail.com', '987456321', 9998745644, '5, Radhe Govind Society', 'Govind Road', 'Manav Ashram'),
(29, 'Gaurav', 'Bilandani', 'gbilandani72@gmail.com', '12345678', 9664560737, '54/ Shree Radhe Township', 'Modhera Road', 'Manav Ashram'),
(19, 'psodi', 'sos', 'gssjd@f.cm', '74185214', 7896547896, '', '', ''),
(28, 'hello', 'world', 'hello@gmail.com', '12345678', 9876543214, '', '', ''),
(21, 'jdjd', 'sfgg', 'lsks@mc.cm', '78965412', 7896541232, '', '', ''),
(1, 'mn', 'memon', 'mn@12gmail.com', '98765432', 9874569874, '', '', ''),
(25, 'vwgbef', 'rgwbeb', 'pbilandani72@gmail.com', 'poiuytre', 848468944962, '', '', ''),
(31, 'snehashish', 'bera', 'snehasishbera908@gmail.com', '123456789', 9874596875, '54 / gurukul heights', 'satya road', 'Balol');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `ProductId` int(11) NOT NULL,
  `ProductName` varchar(20) NOT NULL,
  `ProductDescription` varchar(255) DEFAULT NULL,
  `CatId` int(11) NOT NULL,
  `subcatId` int(11) NOT NULL,
  `Size` int(11) DEFAULT NULL,
  `Qty` int(11) NOT NULL,
  `ProductPrice` int(11) NOT NULL,
  `ProductImage` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`ProductId`, `ProductName`, `ProductDescription`, `CatId`, `subcatId`, `Size`, `Qty`, `ProductPrice`, `ProductImage`) VALUES
(61, 'BYFord', 'Maroon POLO tshirt for man.', 1, 1, 24, 3, 785, 'mt1.jpg'),
(62, 'Lee-cooper', 'yellow cool cotton tshirt for boys', 1, 1, 36, 3, 457, 'mt2.jpeg'),
(63, 'USPolo', 'A classic tees with green and white strips', 1, 1, 36, 4, 984, 'mt6.jpeg'),
(64, 'Team-Spirit', 'Men Collar Printed guess denim polo tshirt', 1, 1, 42, 5, 745, 'mt10.jpeg'),
(65, 'Bare Denim', 'Blue medium low denim jeans with monkey-wash for boys', 1, 1, 50, 5, 654, 'mj1.jpeg'),
(67, 'Lee-cooper', 'Light Wash Blue slim-fit denim jeans', 1, 1, 42, 5, 784, 'mj2.jpeg'),
(68, 'Libaas', 'Libaas floral bliss side pocket cotton kurta set ', 2, 1, 0, 5, 999, 'cw1.jpeg'),
(77, 'CK', 'Black Classy watch for women', 2, 3, 0, 0, 784, 'ww9.jpg'),
(78, 'Timex', 'Fancy Bracelet watch for women', 2, 3, 0, 0, 963, 'ww12.jpg'),
(79, 'shoes', 'Fancy Black shoes for women', 2, 2, 0, 0, 753, 'fw9j.jpeg'),
(80, '3 t-shirt', 'set of 3 t-shirts', 3, 1, 0, 0, 123, 'cb8.jpeg'),
(81, 'shoes', 'children footware', 3, 2, 0, 0, 747, 'fb13.jpeg'),
(83, 'Kid Sun', 'Minion Analog Watch for kids', 3, 3, 0, 0, 86, 'wb11.jpg'),
(87, 'Aqua Blue Shades', 'Round shaped Aqua Blue Shades with Golden Frame for your Beach Adventures.', 1, 4, 0, 0, 954, 'vincent-chase-vc-s11320-full-rem-avit0r-matal-c23-sunglasses_sunglasses_g_3310.jpg'),
(88, 'ELEGANTE Square Sung', 'Branded Smooth Leg Covers Lightweight Square Kabir Singh Sunglasses are suitable for boys and men with small and medium faces.', 1, 4, 0, 0, 754, 'matte-black-brown-full-rim-wayfarer-vincent-chase-athleisure-vc-s14524-c3-sunglasses_j_9067_18_04_2022.jpg'),
(89, 'Octagonal Sunglasses', 'Black Full Rim Geometric Sunglasses', 1, 4, 0, 0, 654, 'john-jacobs-jj-s12811-c2-sunglasses_g_8857.jpg'),
(90, 'Fast Track', 'Brown sunglasses', 1, 4, 0, 0, 999, 'john-jacobs-jj-s11472l-c1-sunglasses_sunglasses_g_9753.jpg'),
(91, 'Vision', 'Eye Glasses', 1, 4, 0, 0, 987, 'john-jacobs-jj-e13026-c1-eyeglasses_john-jacobs-jj-e13026-c1-eyeglasses_g_6994_2.jpg'),
(92, 'Fast Track', 'Black round sunglasses', 1, 4, 0, 0, 988, 'gunmetal-black-grey-full-rim-round-vincent-chase-havana-vc-s14469-c2-polarized-sunglasses_g_9996_08_04_2022.jpg'),
(94, 'BClear', 'Eyeglasses for men', 1, 4, 0, 0, 874, 'a2f47f63b87e6aa8bbbe271b21188545.jpg'),
(95, 'Fast Track', 'Round Gandhi eyeglasses', 1, 4, 0, 0, 784, '4e9a2e9a1cc028926bba22f2d50055fc.jpg'),
(96, 'Red Tape', 'Thick sole sports shoe', 1, 2, 0, 0, 785, '6a412738-c878-43a3-af4d-a372c6291563.webp'),
(97, 'Red Cliff', 'Cool man sandal for casual use', 1, 2, 0, 0, 785, '41quHTxuJ9L.jpg'),
(98, 'Relaxo', 'White sneakers', 1, 2, 0, 0, 789, '-473Wx593H-460903453-offwhite-MODEL.webp'),
(99, 'Puma', 'Printed Sneakers', 1, 2, 0, 0, 753, '-1117Wx1400H-469134694-offwhite-MODEL.webp'),
(100, 'USPolo', 'Grey Sneakers', 1, 2, 0, 0, 984, 'd3e660c6-1f6a-4852-9dcc-ba22788d031f-500x500.jpg'),
(101, 'Campus', 'Combination of formal and ethnic mojadi', 1, 2, 0, 0, 786, 'download.jfif'),
(102, 'Bata', 'Solid Comfort Sandals', 1, 2, 0, 0, 781, 'men-sandle-500x500.png'),
(103, 'Relaxo', 'Fancy kolhapuri chappal', 1, 2, 0, 0, 874, 'prod-20200908-1806231718585047856907568-jpg-500x500.jpg'),
(107, 'Red Tape', 'Grey Sneakers', 1, 2, 0, 0, 987, 'shopping.webp'),
(109, 'IWC', 'Mens Premium Analog watch', 1, 3, 0, 0, 745, '2d98442342f3471e136ea102246e7832.jpg'),
(110, 'Club', 'Analog watch for men', 1, 3, 0, 0, 789, '5bac648d132b120986a6a536-large.jpg'),
(111, 'Sterio', 'Analog watch for men', 1, 3, 0, 0, 987, '8ac443377d49ad4a6fb14c9fe96d8236.jpg'),
(112, 'IWC', 'Analog watch for men', 1, 3, 0, 0, 899, '68afe960a95c4fb25edc686ea10d6a7b.jpg'),
(114, 'Espair', 'Analog watch for men', 1, 3, 0, 0, 998, '139961841-90340846-1531992672.jpg'),
(115, 'Movado', 'Analog watch for men', 1, 3, 0, 0, 999, 'd0650c9fa000c18e3f377b690dba7075.jpg'),
(117, 'David Wellington', 'Analog watch for men', 1, 3, 0, 0, 398, 'dw00100481_1_6f2b7977.webp'),
(118, 'Montera', 'Premium Analog watch for men', 1, 3, 0, 0, 399, 'fa089a340ca30f46fc446ec03427ec6d.jpg'),
(120, 'Error', 'Analog watch for men with two timings', 1, 3, 0, 0, 299, 'Le-Regulateur-Louis-Erard-x-seconde-seconde-Portrait-Faded.webp'),
(121, 'Nomos', 'Analog watch for men', 1, 3, 0, 0, 395, 'mens-luxury-watches-1627593848.jpg'),
(128, 'Jaipuri Bunai', 'Jaipuri Bunai women teal printed kurta with dupatta', 2, 1, 0, 0, 777, '30b0017d-7e72-4d40-9633-ef78d01719741575541717470-AHIKA-Women-Black--Green-Printed-Straight-Kurta-990157554171-1.jpg'),
(129, 'Street 9', 'Peach kaftani top', 2, 1, 0, 0, 789, '41pgvp52ziL.jpg'),
(130, 'H&M', 'Women blue high jeans', 2, 1, 0, 0, 874, '59e665b8e864f2395d24f687fafcfbe4.png'),
(131, 'Code 61', 'Women Blue fit high streachable jeans', 2, 1, 0, 0, 897, '61nLL6RGUzL._UY550_.jpg'),
(132, 'Vishudh', 'Women orange anarkali kurta', 2, 1, 0, 0, 899, '3355def08a20ca680c778412c330d815.jpg'),
(133, 'Pankh', 'Floral top', 2, 1, 0, 0, 777, 'H2aed9e520d0948bfa8f642d9eb3be3b1z.jpg'),
(135, 'Forever New', 'Cotton A-line top', 2, 1, 0, 0, 888, 'images.jfif'),
(136, 'Puma', 'Puma Women Pink Sweat-Shirt', 2, 1, 0, 0, 889, 'otinr_512.jpg'),
(137, 'Only', 'Red Sold Crop Top', 2, 1, 0, 0, 998, 'product-jpeg-500x500.jpg'),
(138, 'Rare', 'Body-con Dress ', 2, 1, 0, 0, 877, 'abc.jfif'),
(139, 'Voyage', 'Women Sunglasses', 2, 4, 0, 0, 899, 'black-full-rim-round-vincent-chase-havana-vc-s14678-c4-polarized-sunglasses_g_1525_17_05_2022.jpg'),
(140, 'Dress-berry', 'UV protected lenses round sunglasses', 2, 4, 0, 0, 787, 'gold-tortoise-blue-gradient-full-rim-round-vincent-chase-polarized-havana-vc-s14469-c4-sunglasses_g_0022_4_12_22.jpg'),
(141, 'Duke', 'Blue lens and round glasses', 2, 4, 0, 0, 874, 'gold-tortoise-blue-gradient-full-rim-square-vincent-chase-havana-vc-s14471-vc-s14471-c4-polarized-sunglasses_g_9863_26_04_2022.jpg'),
(142, 'Tom Ford', 'Black and orange UV protected sunglasses', 2, 4, 0, 0, 856, 'Gold-Tortoise-Grey-Full-Rim-Round-Vincent-Chase-Polarized-HAVANA-VC-S14481-C4-Sunglasses_vincent-chase-vc-s14481-c4-sunglasses_J_151018_02_2022.jpg'),
(143, 'Lee-cooper', 'Glass frame Blue shade glasses ', 2, 4, 0, 0, 569, 'Gunmetal-Blue-Full-Rim-Round-Vincent-Chase-Polarized-HAVANA-VC-S14481-C1-Sunglasses_vincent-chase-vc-s14481-c1-sunglasses_J_150418_02_2022.jpg'),
(144, 'Ted-Smith', 'Women orange cat eye sunglasses', 2, 4, 0, 0, 568, 'pink-full-rim-cat-eye-vincent-chase-havana-vc-s14677-c3-polarized-sunglasses_g_1511_17_05_2022.jpg'),
(146, 'Black-Jones', 'Imported stylish sunglasses', 2, 4, 0, 0, 799, 'pink-transparent-silver-green-gradient-full-rim-cat-eye-vincent-chase-havana-vc-s14674-c4-polarized-sunglasses_csvfile-1652868649581-g_1360.jpg'),
(147, '20-Dresses', 'Vibe all day sunglasses', 2, 4, 0, 0, 789, 'tortoise-full-rim-round-vincent-chase-havana-vc-s14678-c2-polarized-sunglasses_g_1518_17_05_2022.jpg'),
(148, 'Ted-Smith', 'Octagonal orange shade Polarised sunglasses', 2, 4, 0, 0, 859, 'vincent-chase-vc-s14463-c4-sunglasses_g_9555.jpg'),
(149, 'Pipa-Bella', 'Chic Black Square sunglasses', 2, 4, 0, 0, 951, 'vincent-chase-vc-s14463-c5-sunglasses_g_9630.jpg'),
(150, 'Retro', 'Octagonal Sunglasses', 2, 4, 0, 0, 597, 'vincent-chase-vc-s14464-c1-sunglasses_g_9597.jpg'),
(151, 'Fashion-Ride', 'Nova Heels', 2, 2, 0, 0, 879, '4-500x500.jpg'),
(152, 'HRX', 'Women Alpha training shoes', 2, 2, 0, 0, 877, '4-mw-1102-women-white-4-mileswalker-white-original-imagyn5egchvbmrh.webp'),
(153, 'Crocks', 'Navy Blue Comfort Sandals', 2, 2, 0, 0, 987, '8f1cbfab9714bc3e746ed57fbaffd7ab49c12f37_original.jpeg'),
(154, 'Metro', 'Solid high platform heels', 2, 2, 0, 0, 859, '61Ch4HXLnEL._UL1500_.jpg'),
(155, 'Ink-5', 'Orange Partywear Comfort sandals', 2, 2, 0, 0, 829, '81fEmhM-VUS._UL1500_.jpg'),
(156, 'Picktoes', 'Textured heels', 2, 2, 0, 0, 819, '-473Wx593H-460781896-green-MODEL.webp'),
(157, 'INC5', 'Fancy Chappals', 2, 2, 0, 0, 729, '11457289782.jpg'),
(159, 'Cat-Walk', 'Women heels sandals', 2, 2, 0, 0, 789, 'downloadab.jfif'),
(160, 'Shoetopia', 'Block Sandals', 2, 2, 0, 0, 894, 'istockphoto-1298187166-170667a.jpg'),
(161, 'Jaipuria Bellies', 'Floral work Jaipuria Bellies', 2, 2, 0, 0, 839, 'pri_175_p-1650016892.webp'),
(162, 'twin-toes', 'Women Block Sandals', 2, 2, 0, 0, 869, 'W880H747-pichi.jpg'),
(163, 'Olivia Burton', 'Fancy Women Analog Watch', 2, 3, 0, 0, 849, '2adcd465a88940b0c91d921e8d20074b.jpg'),
(164, 'Dress-berry', 'Women Analog Watch', 2, 3, 0, 0, 879, '4f5f1ce9a80987dd3da1184ffe8b1ce2.jpg'),
(165, 'Noice', 'Women Analog Watch', 2, 3, 0, 0, 859, '818a5b0b9a21d59cdad1eac3e56552f4.jpg'),
(166, 'Rolex', 'Women Analog Watch', 2, 3, 0, 0, 929, '019691ccc6bff9ec82a824048cd3f809.jpg'),
(167, 'Fast Track', 'Women Analog Watch', 2, 3, 0, 0, 710, 'a8c6ea02fa8aec3ef20fd5187246da8e.jpg'),
(168, 'French Connection', 'Women Analog Watch', 2, 3, 0, 0, 740, 'a9df9f1e8d33e9bc71975d4c9a6bf26d.jpg'),
(170, 'Fossil', 'Women Chain Analog Watch', 2, 3, 0, 0, 753, 'b36e0fb1310bf46a656c1d16af843874.jpg'),
(171, 'Boaty', 'Women Analog Watch with Bracelet set', 2, 3, 0, 0, 845, 'be4414a630e7113a464489c53a98db48.jpg'),
(172, 'Armani Exchange', 'Women Analog Watch', 2, 3, 0, 0, 849, 'bee6491d3ac5fd7240592faf4d4fd781.jpg'),
(173, 'Micheal Kors', 'Women Bracelet analog watch', 2, 3, 0, 0, 741, 'cc5cf12e5a20de50c12ab95c4cfff894.jpg'),
(174, 'CK', 'Women Analog Watch', 2, 3, 0, 0, 450, '575eb8349674eef5f9f6e6a50a370141.jpg'),
(175, 'Daniel-Klein', 'Women Analog Watch', 2, 3, 0, 0, 456, 'd1f1ac8b9f207aa60e0ee73678be5a56.jpg'),
(176, 'Guess', 'Women Stailess steel analog watch', 2, 3, 0, 0, 452, 'd67c140c4038e0f6f8596f411ead184b.jpg'),
(177, 'Toffy-House', 'Toffy House Rompers ', 3, 1, 0, 0, 743, '41+7Nc5FuKL.jpg'),
(178, 'Team-Spirit', 'Blue Tshirt with Pants', 3, 1, 0, 0, 452, '51nUfiMuCLL._UX679_.jpg'),
(179, 'High Frame', 'Print ALine Dress', 3, 1, 0, 0, 541, '97b31873-9e39-41a8-bf5c-76a6d6a51b361643456653743ClothingSet1.webp'),
(180, 'Disney', 'Floral printed Dungri Set with Shoes', 3, 1, 0, 0, 521, '9497555a.webp'),
(181, 'KG', 'Fit and flare dress', 3, 1, 0, 0, 850, 'aaaaaa.jfif'),
(182, 'Rio Girls', 'ALine dress', 3, 1, 0, 0, 471, 'bird-print-blue-casual-dress-500x500.jpg'),
(183, 'Tior', 'Skirt for girls', 3, 1, 0, 0, 412, 'ila-46217-1.jpg'),
(184, 'Gini&Joy', 'Set of 4 printed shirts with pant', 3, 1, 0, 0, 456, 'Kids-clothes-Summer-leaves-Print-Cartoon-Short-Sleeve-children-clothes-Shirt-Pants-for-Toddler-Baby-Boys-Clothes-Boy-Kid.webp'),
(185, 'Kurta', 'Blue kurta set', 3, 1, 0, 0, 547, 'sky-blue-jacquard-silk-kurta-pyjama-kdbsrk527-pl.jpg'),
(186, 'Toffy-House', 'Partywear Suit for kids', 3, 1, 0, 0, 651, 'spring-autumn-boys-clothing-set-SDL561456550-1-bc6c8.jpg'),
(187, 'Zero Peasant', 'Sleaveless frock dress for girls', 3, 1, 0, 0, 526, 'STAR3_1024x1024.jpg'),
(188, 'Pine Kids', 'Fancy Digital watch with lighting for kids', 3, 3, 0, 0, 129, '81mOgzf-MxL.jpg'),
(189, 'Kool Kids', 'Kids watch with lighting', 3, 3, 0, 0, 210, '9985934a.webp'),
(190, 'Baby Hug', 'Kids analog watch ', 3, 3, 0, 0, 781, 'C4048PP25_1.webp'),
(192, 'Baby Oye', 'Barbie analog watch for girls', 3, 3, 0, 0, 741, 'downloadabas.jfif'),
(193, 'Baby Hug', 'Minnie analog watch', 3, 3, 0, 0, 542, '221493284175.jpg'),
(194, 'Kids Ville', 'Cool Batman analog watch with Band', 3, 3, 0, 0, 560, '1563262905934_0..webp'),
(195, 'Baby Oye', 'Cute analog watch for kids', 3, 3, 0, 0, 569, 'analog._SS680_QL85_.jpg'),
(196, 'Baby Hug', 'partywear bellies for girls', 3, 2, 0, 0, 745, '3-880007080white-pantaloons-junior-original-imag4nt5jzpgzage.webp'),
(197, 'Baby Oye', 'Pearl baby sandals', 3, 2, 0, 0, 745, 'DSC00282.webp'),
(199, 'Baby Hug', 'casual shoes', 3, 2, 0, 0, 740, 'efre.webp'),
(200, 'Cute Walk', 'Partywear sandals', 3, 2, 0, 0, 452, 'gwegw.webp'),
(201, 'Cute Walk', 'Comfortable Baby shoes', 3, 2, 0, 0, 541, 'hel.webp'),
(202, 'Baby Oye', 'Blue Crocks by Baby Oye', 3, 2, 0, 0, 500, 'hello.webp'),
(204, 'Bunny', 'pink sandals', 3, 2, 0, 0, 546, 'rwg.webp'),
(205, 'Kids Ville', 'white polka-dot canvas shoes ', 3, 2, 0, 0, 600, 'wrw.webp'),
(206, 'Campus', 'kids pink shoes', 3, 2, 0, 0, 400, 'gsbd.webp'),
(207, 'Purple', 'Pine kids glasses', 3, 4, 0, 0, 453, '0QQS-t3M.jpeg'),
(208, 'Kid Sun', 'Cute Cat shaped sunglasses for girls', 3, 4, 0, 0, 410, '31JbM+BOskL.jpg'),
(209, 'Baby Hug', 'Aviator Glasses', 3, 4, 0, 0, 410, '51aHNarLoAL._UX679_.jpg'),
(210, 'Pine Kids', 'Pine kids round glasses', 3, 4, 0, 0, 399, '51AuAWRZrnS._UX679_.jpg'),
(211, 'Baby Oye', 'Kids sunglasses', 3, 4, 0, 0, 358, '51HJwSH9uQL._UX679_.jpg'),
(212, 'Baby Hug', 'Kids sunglasses', 3, 4, 0, 0, 451, '446057_1599537311253.webp'),
(213, 'Kid Sun', 'Printed frame glasses', 3, 4, 0, 0, 258, 'asdfg.jfif'),
(217, 'Hangup', 'Green over sized wool coat', 1, 1, 0, 0, 899, 'mens-long-coat-500x500.jpg'),
(218, 'Jack & Jones', 'Mid rise jeans', 1, 1, 0, 0, 789, 'hip-hop-trend-ripped-men-jeans-500x500.jpg'),
(219, 'T-shirt', 'New Tshirt', 1, 1, 0, 0, 1799, 'luca-faloni-linen-shirt.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `quantity`
--

CREATE TABLE `quantity` (
  `QtyId` int(11) NOT NULL,
  `Qty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `quantity`
--

INSERT INTO `quantity` (`QtyId`, `Qty`) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5);

-- --------------------------------------------------------

--
-- Table structure for table `size`
--

CREATE TABLE `size` (
  `Size_Id` int(11) NOT NULL,
  `Size` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `size`
--

INSERT INTO `size` (`Size_Id`, `Size`) VALUES
(1, 24),
(2, 36),
(3, 42),
(4, 50);

-- --------------------------------------------------------

--
-- Table structure for table `subcategory`
--

CREATE TABLE `subcategory` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subcategory`
--

INSERT INTO `subcategory` (`id`, `name`) VALUES
(1, 'Clothing'),
(2, 'Footware'),
(3, 'Watch'),
(4, 'Sunglasses');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adminlogin`
--
ALTER TABLE `adminlogin`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`CatId`);

--
-- Indexes for table `color`
--
ALTER TABLE `color`
  ADD PRIMARY KEY (`Color_Id`);

--
-- Indexes for table `databaselos`
--
ALTER TABLE `databaselos`
  ADD PRIMARY KEY (`email`),
  ADD UNIQUE KEY `unique` (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`ProductId`);

--
-- Indexes for table `quantity`
--
ALTER TABLE `quantity`
  ADD PRIMARY KEY (`QtyId`);

--
-- Indexes for table `size`
--
ALTER TABLE `size`
  ADD PRIMARY KEY (`Size_Id`);

--
-- Indexes for table `subcategory`
--
ALTER TABLE `subcategory`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `CatId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `color`
--
ALTER TABLE `color`
  MODIFY `Color_Id` int(7) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `databaselos`
--
ALTER TABLE `databaselos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `ProductId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=220;

--
-- AUTO_INCREMENT for table `quantity`
--
ALTER TABLE `quantity`
  MODIFY `QtyId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `size`
--
ALTER TABLE `size`
  MODIFY `Size_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `subcategory`
--
ALTER TABLE `subcategory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
